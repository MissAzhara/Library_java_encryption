import java.util.*;

import lib.crypto.files.*;

public class Entry {
	private static Scanner scan = null;

	public static void testAES(ICrypto aes, String plain) {
		try {
			byte[] cipher = aes.encrypt(plain);

			System.out.print("cipher:  ");
			for (int i = 0; i < cipher.length; i++)
				System.out.print(new Integer(cipher[i])+" ");

			System.out.println("");

			String decrypted = aes.decrypt(cipher);

			System.out.println("decrypt: " + decrypted);

	    } catch (Exception e) {
	    	e.printStackTrace();
	    }

	}

	public static void testMD5(ICrypto md5, String text) {
		System.out.println("Generated string:");

		try {
			System.out.println(new String(md5.encrypt(text)));
		} catch(Exception e) {

		}
	}

	public static void testRSA(ICrypto rsa, String plain) {
		try {
			byte[] encrypt = rsa.encrypt(plain);
			String decrypt = rsa.decrypt(encrypt);

			System.out.println("decrypted: " + decrypt);

	    } catch (Exception e) {
	    	e.printStackTrace();
	    }

	}

	private static final String HR = "_______________________________";
	public static void createHr() {
		System.out.println(HR);
	}

	public static void main(String[] args) {
		scan = new Scanner(System.in);

		createHr();
		System.out.println("Test module AES");
		System.out.println("Input text: test text 123"); /* "test text 123\0\0\0" */
		String plain = "test text 123\0\0\0";
			
		System.out.print("Input key: 0123456789abcdef");
		String key = "0123456789abcdef";

		System.out.println("Input IV: 'AAAAAAAAAAAAAAAA'");
		String iv = "AAAAAAAAAAAAAAAA";

		AES aes = new AES(key, iv);

		testAES(aes, plain);
		

		createHr();
		System.out.println("Test module RSA");

		System.out.println("Input N: 12");
		int N = 12;	

		RSA rsa = new RSA(N);
			
		System.out.println("Input text: 123");
		plain = "123";

		testRSA(rsa, plain);

		createHr();
		System.out.println("Test module MD5");

		MD5 md5 = new MD5();

		System.out.print("Input text: ");
		String text = scan.next();

		testMD5(md5, text);
		
		System.out.println("\nExit program");	
	     
	}

} 
