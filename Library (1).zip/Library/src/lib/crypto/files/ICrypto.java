package lib.crypto.files;

public interface ICrypto {
	public byte[] encrypt(String plainText) throws Exception;
	public String decrypt(byte[] cipherText) throws Exception;
}