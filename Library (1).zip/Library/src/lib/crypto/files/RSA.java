package lib.crypto.files;

import java.math.BigInteger;
import java.security.SecureRandom;

public class RSA implements ICrypto {
   private final static BigInteger one = new BigInteger("1");
   private final static SecureRandom random = new SecureRandom();

   private BigInteger privateKey;
   private BigInteger publicKey;
   private BigInteger modulus;

   public RSA(int N) {
      BigInteger p = BigInteger.probablePrime(N / 2, random);
      BigInteger q = BigInteger.probablePrime(N / 2, random);
      BigInteger phi = (p.subtract(one)).multiply(q.subtract(one));

      modulus    = p.multiply(q);                                  
      publicKey  = new BigInteger("65537"); // 2^16 + 1
      privateKey = publicKey.modInverse(phi);
   }


   public byte[] encrypt(String plainText) throws Exception {
      BigInteger tmp = new BigInteger(plainText);
      return tmp.modPow(publicKey, modulus).toByteArray();
   }

   public String decrypt(byte[] cipherText) throws Exception {
      BigInteger tmp = new BigInteger(cipherText);
      return tmp.modPow(privateKey, modulus).toString();
   }
}